
Choose recording settings, minimize Screen of Death, record when ready.

Shortcuts: Record-Ctrl-Shift-R
                  Stop-Ctrl-Shift-S

