from __future__ import annotations

import os
import re
import sys
import time
import tempfile
import threading
import subprocess
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, QMetaObject, pyqtSignal, QObject, Q_ARG
from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPushButton, QSplashScreen,
    QVBoxLayout, QWidget,
)

import mss
import keyboard

# =============================================================================
# Windows Bootstrap
# =============================================================================

if sys.platform == "win32":
    import ctypes
    CREATE_NO_WINDOW = 0x08000000
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
        "DeathsHeadSoftware.ScreenOfDeath"
    )
else:
    CREATE_NO_WINDOW = 0

# =============================================================================
# Constants
# =============================================================================

APP_NAME    = "Screen of Death"
ORG_NAME    = "Death's Head Software"
APP_VERSION = "1.0.0"

HOTKEY_RECORD = "ctrl+shift+r"
HOTKEY_STOP   = "ctrl+shift+s"

# =============================================================================
# Helpers
# =============================================================================

def resource_path(relative: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base, relative)


def get_monitors() -> list[tuple[str, dict]]:
    result = []
    with mss.MSS() as sct:
        result.append(("All Monitors", sct.monitors[0]))
        for i, mon in enumerate(sct.monitors[1:], 1):
            w, h = mon["width"], mon["height"]
            result.append((f"Monitor {i}  ({w}x{h})", mon))
    return result


def get_mic_devices() -> list[str]:
    """
    Enumerate DirectShow audio devices for use as microphone inputs.
    Returns ['No Mic', ...device names...].
    """
    devices: list[str] = ["No Mic"]
    try:
        proc = subprocess.run(
            ["ffmpeg", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=CREATE_NO_WINDOW,
        )
        for line in proc.stderr.splitlines():
            if "Alternative name" in line:
                continue
            # ffmpeg 8.x: flat list with inline (audio)/(video) tags
            m = re.search(r'"([^"]+)"\s*\(audio\)', line)
            if m:
                name = m.group(1).strip()
                if name and name not in devices:
                    devices.append(name)
    except Exception as exc:
        print(f"[mic enum] {exc}")
    return devices

def get_system_audio_devices() -> list[tuple[str, str, str]]:
    """
    Enumerate system audio sources for loopback recording.
    Returns list of (display_label, source_type, device_name) tuples.
    source_type is 'wasapi' or 'dshow'. First entry is always the no-audio sentinel.

    Two strategies:
      1. WASAPI output devices — most reliable when ffmpeg supports them.
      2. dshow 'Stereo Mix' / 'Wave Out' / 'What U Hear' devices — fallback
         for systems where WASAPI enumeration returns nothing.
    """
    devices: list[tuple[str, str, str]] = [("No System Audio", "", "")]

    # --- Strategy 1: WASAPI output devices ---
    try:
        proc = subprocess.run(
            ["ffmpeg", "-list_devices", "true", "-f", "wasapi", "-i", "dummy"],
            capture_output=True, text=True, timeout=10,
            creationflags=CREATE_NO_WINDOW,
        )
        for line in proc.stderr.splitlines():
            if "Alternative name" in line or "(input)" in line:
                continue
            m = re.search(r'"([^"]+)"', line)
            if m:
                name = m.group(1).strip()
                if name:
                    devices.append((f"{name}", "wasapi", name))
    except Exception as exc:
        print(f"[wasapi enum] {exc}")

    # --- Strategy 2: dshow loopback/stereo-mix devices ---
    # These show up in the regular dshow audio list under names like
    # "Stereo Mix", "Wave Out Mix", "What U Hear", etc.
    LOOPBACK_KEYWORDS = ["stereo mix", "wave out", "what u hear", "loopback"]
    try:
        proc = subprocess.run(
            ["ffmpeg", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True, text=True, timeout=10,
            creationflags=CREATE_NO_WINDOW,
        )
        known = {d[2] for d in devices}
        for line in proc.stderr.splitlines():
            if "Alternative name" in line:
                continue
            m = re.search(r'"([^"]+)"\s*\(audio\)', line)
            if m:
                name = m.group(1).strip()
                if name and name not in known:
                    if any(kw in name.lower() for kw in LOOPBACK_KEYWORDS):
                        devices.append((name, "dshow", name))
    except Exception as exc:
        print(f"[dshow system enum] {exc}")

    return devices

# =============================================================================
# Hardware Encoder Detection
# =============================================================================

def detect_hw_encoder() -> tuple[str, str]:
    """
    Probe for hardware H.264 encoders in preference order.
    Each candidate gets a quick 0.1-second null encode test.
    Returns (ffmpeg_encoder_name, display_label).
    Falls back to libx264 (CPU) if nothing is found.
    """
    candidates = [
        ("h264_nvenc", "NVENC (NVIDIA)"),
        ("h264_amf",   "AMF (AMD)"),
        ("h264_qsv",   "QSV (Intel)"),
    ]
    for enc, label in candidates:
        try:
            result = subprocess.run(
                [
                    "ffmpeg",
                    "-f", "lavfi", "-i", "color=c=black:s=64x64:r=1:d=0.1",
                    "-c:v", enc,
                    "-f", "null", "-",
                ],
                capture_output=True,
                timeout=6,
                creationflags=CREATE_NO_WINDOW,
            )
            if result.returncode == 0:
                print(f"[encoder] using {label}")
                return enc, label
        except Exception as exc:
            print(f"[encoder] {enc} probe failed: {exc}")
    print("[encoder] falling back to libx264 (CPU)")
    return "libx264", "x264 (CPU)"


def encoder_video_args(encoder: str) -> list[str]:
    """Return the ffmpeg video encoding args for the detected encoder."""
    if encoder == "h264_nvenc":
        return [
            "-c:v", "h264_nvenc",
            "-preset", "p4",        # p1=fastest … p7=best quality
            "-rc", "constqp",       # constant quantiser ≈ CRF for nvenc
            "-qp", "20",
            "-b:v", "0",            # no bitrate cap — let qp drive quality
        ]
    elif encoder == "h264_amf":
        return [
            "-c:v", "h264_amf",
            "-quality", "balanced",
            "-rc", "cqp",
            "-qp_i", "22", "-qp_p", "22", "-qp_b", "22",
        ]
    elif encoder == "h264_qsv":
        return [
            "-c:v", "h264_qsv",
            "-preset", "medium",
            "-global_quality", "22",
            "-look_ahead", "0",     # disable lookahead — reduces encoder latency and sync drift
        ]
    else:  # libx264
        return [
            "-c:v", "libx264",
            "-preset", "faster",
            "-tune", "zerolatency",
            "-crf", "23",
            "-pix_fmt", "yuv420p",
        ]

# =============================================================================
# Hotkey Bridge
# =============================================================================

class HotkeyBridge(QObject):
    """
    Emits Qt signals from the keyboard library's background thread.
    Cross-thread signal emission is safe in Qt — the event loop dispatches
    the call to the main thread.
    """
    record_triggered = pyqtSignal()
    stop_triggered   = pyqtSignal()

# =============================================================================
# Splash
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(40); r.setBottom(100)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 100); fr.setBottom(pixmap.height() - 50)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(40); r.setBottom(100)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull):
                painter.drawText(250, 250 + i * 25, line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 50); fr.setBottom(pixmap.height())
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as exc:
        print(f"Splash error: {exc}")
        return None

# =============================================================================
# Recording Worker
# =============================================================================

class RecordingWorker(QObject):
    finished = pyqtSignal()
    error    = pyqtSignal(str)

    STARTUP_GRACE = 3.0

    def __init__(self, cmd: list[str]) -> None:
        super().__init__()
        self._cmd      = cmd
        self._process: subprocess.Popen | None = None
        self._log_path = os.path.join(tempfile.gettempdir(), "screen_of_death_ffmpeg.log")

    def start(self) -> None:
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        log_fh = None
        try:
            log_fh = open(self._log_path, "w", encoding="utf-8", errors="replace")
            print("[ffmpeg cmd]", " ".join(self._cmd), flush=True)

            self._process = subprocess.Popen(
                self._cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=log_fh,
                creationflags=CREATE_NO_WINDOW,
            )
            t_start = time.monotonic()
            self._process.wait()
            elapsed = time.monotonic() - t_start

            if elapsed < self.STARTUP_GRACE:
                tail = self._read_log_tail()
                self.error.emit(tail)
                return

        except FileNotFoundError:
            self.error.emit("ffmpeg not found.\nMake sure ffmpeg is on your PATH.")
            return
        except Exception as exc:
            self.error.emit(str(exc))
            return
        finally:
            if log_fh:
                log_fh.close()

        self.finished.emit()

    def stop(self) -> None:
        proc = self._process
        if proc and proc.poll() is None:
            try:
                proc.stdin.write(b"q\n")
                proc.stdin.flush()
            except Exception:
                pass
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()

    def _read_log_tail(self, lines: int = 20) -> str:
        try:
            with open(self._log_path, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            return "".join(all_lines[-lines:]).strip()
        except Exception:
            return "(no log available)"

# =============================================================================
# Stylesheet
# =============================================================================

DARK_STYLE = """
QWidget {
    background-color: #141414;
    color: #e0e0e0;
    font-family: Courier;
    font-size: 12px;
}
QComboBox {
    background-color: #1e1e1e;
    border: 1px solid #444;
    padding: 4px 6px;
    color: #e0e0e0;
}
QComboBox::drop-down { border: none; }
QComboBox QAbstractItemView {
    background-color: #1e1e1e;
    selection-background-color: #8b0000;
    color: #e0e0e0;
    border: 1px solid #555;
}
QLineEdit {
    background-color: #1e1e1e;
    border: 1px solid #444;
    padding: 4px 6px;
    color: #e0e0e0;
}
QPushButton {
    background-color: #1e1e1e;
    border: 1px solid #555;
    padding: 4px 10px;
    color: #e0e0e0;
}
QPushButton:hover {
    background-color: #2a2a2a;
    border-color: #8b0000;
}
QPushButton#record_btn {
    background-color: #8b0000;
    border: 1px solid #cc0000;
    color: #ffffff;
    font-weight: bold;
    font-size: 13px;
    padding: 10px;
    letter-spacing: 1px;
}
QPushButton#record_btn:hover { background-color: #aa0000; }
QPushButton#stop_btn {
    background-color: #3a3a3a;
    border: 1px solid #666;
    color: #cccccc;
    font-weight: bold;
    font-size: 13px;
    padding: 10px;
    letter-spacing: 1px;
}
QPushButton#stop_btn:hover {
    background-color: #4a4a4a;
    border-color: #999;
}
QPushButton#log_btn {
    background-color: #1e1e1e;
    border: 1px solid #333;
    color: #555;
    font-size: 10px;
    padding: 2px 8px;
}
QPushButton#log_btn:hover { color: #ccc; border-color: #666; }
QLabel            { color: #d0d0d0; }
QLabel#title_label  { color: #ffffff; }
QLabel#org_label    { color: #444444; font-size: 10px; }
QLabel#timer_label  { color: #cc0000; font-size: 18px; font-weight: bold; letter-spacing: 2px; }
QLabel#status_label { color: #666666; font-size: 10px; }
QLabel#hotkey_label { color: #333333; font-size: 10px; }
QFrame            { color: #2a2a2a; }
QMessageBox {
    background-color: #141414;
    color: #e0e0e0;
}
QMessageBox QLabel {
    color: #e0e0e0;
    background-color: #141414;
}
QMessageBox QPushButton {
    background-color: #2a2a2a;
    border: 1px solid #555;
    color: #e0e0e0;
    padding: 4px 16px;
    min-width: 60px;
}
QMessageBox QPushButton:hover {
    background-color: #3a3a3a;
    border-color: #8b0000;
}
QTextEdit {
    background-color: #1e1e1e;
    color: #e0e0e0;
    border: 1px solid #444;
}
"""

# =============================================================================
# Main Window
# =============================================================================

class ScreenOfDeath(QWidget):

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(420, 400)
        self.setStyleSheet(DARK_STYLE)

        icon_path = resource_path("splash.png")
        if Path(icon_path).exists():
            self.setWindowIcon(QIcon(icon_path))

        self._worker:     RecordingWorker | None = None
        self._elapsed:    int                    = 0
        self._output_dir: str                    = str(Path.home() / "Videos")

        self._tick_timer = QTimer(self)
        self._tick_timer.timeout.connect(self._tick)

        self._last_hotkey_time: float = 0.0

        self._monitors      = get_monitors()
        self._mic_devices   = get_mic_devices()
        self._sys_devices   = get_system_audio_devices()  # list of (label, type, name)
        self._encoder, self._encoder_label = detect_hw_encoder()

        # Hotkey bridge — lives on main thread, signals dispatched via event loop
        self._hk = HotkeyBridge()
        self._hk.record_triggered.connect(self._on_hotkey_record)
        self._hk.stop_triggered.connect(self._on_hotkey_stop)
        self._register_hotkeys()

        self._build_ui()

    # ------------------------------------------------------------------
    # Hotkeys
    # ------------------------------------------------------------------

    def _register_hotkeys(self) -> None:
        try:
            keyboard.add_hotkey(HOTKEY_RECORD, self._hk.record_triggered.emit, suppress=True)
            keyboard.add_hotkey(HOTKEY_STOP,   self._hk.stop_triggered.emit,   suppress=True)
        except Exception as exc:
            print(f"[hotkey] registration failed: {exc}")

    def _on_hotkey_record(self) -> None:
        now = time.monotonic()
        if now - self._last_hotkey_time < 1.5:
            return
        self._last_hotkey_time = now
        if self._worker is None:
            self._start_recording()

    def _on_hotkey_stop(self) -> None:
        now = time.monotonic()
        if now - self._last_hotkey_time < 1.5:
            return
        self._last_hotkey_time = now
        if self._worker is not None:
            self._stop_recording()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setSpacing(8)
        root.setContentsMargins(16, 14, 16, 14)

        # Header
        title = QLabel(APP_NAME)
        title.setObjectName("title_label")
        title.setFont(QFont("Courier", 16, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(title)

        org = QLabel(ORG_NAME)
        org.setObjectName("org_label")
        org.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(org)

        root.addWidget(self._sep())

        # Monitor
        row = QHBoxLayout()
        lbl = QLabel("Monitor:"); lbl.setFixedWidth(68)
        row.addWidget(lbl)
        self.monitor_combo = QComboBox()
        for label, _ in self._monitors:
            self.monitor_combo.addItem(label)
        row.addWidget(self.monitor_combo, 1)
        root.addLayout(row)

        # Mic
        row2 = QHBoxLayout()
        lbl2 = QLabel("Mic:"); lbl2.setFixedWidth(68)
        row2.addWidget(lbl2)
        self.mic_combo = QComboBox()
        for dev in self._mic_devices:
            self.mic_combo.addItem(dev)
        row2.addWidget(self.mic_combo, 1)
        root.addLayout(row2)

        # System audio
        row3 = QHBoxLayout()
        lbl3 = QLabel("System:"); lbl3.setFixedWidth(68)
        row3.addWidget(lbl3)
        self.sys_combo = QComboBox()
        for label, _, _ in self._sys_devices:
            self.sys_combo.addItem(label)
        row3.addWidget(self.sys_combo, 1)
        root.addLayout(row3)

        # Framerate
        row4 = QHBoxLayout()
        lbl4 = QLabel("FPS:"); lbl4.setFixedWidth(68)
        row4.addWidget(lbl4)
        self.fps_combo = QComboBox()
        for fps in ["30 fps", "60 fps"]:
            self.fps_combo.addItem(fps)
        self.fps_combo.setCurrentIndex(0)   # default 30fps
        row4.addWidget(self.fps_combo, 1)
        root.addLayout(row4)

        # Encoder (read-only — auto-detected at startup)
        enc_row = QHBoxLayout()
        elbl = QLabel("Encoder:"); elbl.setFixedWidth(68)
        enc_row.addWidget(elbl)
        self.encoder_label = QLabel(self._encoder_label)
        self.encoder_label.setStyleSheet("color: #cc0000; font-size: 11px;")
        enc_row.addWidget(self.encoder_label, 1)
        root.addLayout(enc_row)

        root.addWidget(self._sep())

        # Output dir
        dir_row = QHBoxLayout()
        dlbl = QLabel("Dir:"); dlbl.setFixedWidth(68)
        dir_row.addWidget(dlbl)
        self.dir_label = QLabel(self._output_dir)
        self.dir_label.setStyleSheet("color: #c0c0c0; font-size: 11px;")
        dir_row.addWidget(self.dir_label, 1)
        browse_btn = QPushButton("...")
        browse_btn.setFixedWidth(28)
        browse_btn.clicked.connect(self._choose_dir)
        dir_row.addWidget(browse_btn)
        root.addLayout(dir_row)

        # Filename
        fn_row = QHBoxLayout()
        fnlbl = QLabel("File:"); fnlbl.setFixedWidth(68)
        fn_row.addWidget(fnlbl)
        self.filename_edit = QLineEdit("recording.mp4")
        fn_row.addWidget(self.filename_edit, 1)
        root.addLayout(fn_row)

        root.addWidget(self._sep())

        # Timer
        self.timer_label = QLabel("00:00:00")
        self.timer_label.setObjectName("timer_label")
        self.timer_label.setFont(QFont("Courier", 18, QFont.Weight.Bold))
        self.timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self.timer_label)

        # Status + log button
        status_row = QHBoxLayout()
        self.status_label = QLabel("Ready")
        self.status_label.setObjectName("status_label")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_row.addWidget(self.status_label, 1)
        self.log_btn = QPushButton("view log")
        self.log_btn.setObjectName("log_btn")
        self.log_btn.setFixedWidth(62)
        self.log_btn.clicked.connect(self._show_log)
        status_row.addWidget(self.log_btn)
        root.addLayout(status_row)

        # Record / Stop button
        self.record_btn = QPushButton("  RECORD")
        self.record_btn.setObjectName("record_btn")
        self.record_btn.clicked.connect(self._toggle)
        root.addWidget(self.record_btn)

        # Hotkey hint
        hk_label = QLabel(
            f"Hotkeys:  {HOTKEY_RECORD.upper()} = record    {HOTKEY_STOP.upper()} = stop"
        )
        hk_label.setObjectName("hotkey_label")
        hk_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(hk_label)

    @staticmethod
    def _sep() -> QFrame:
        f = QFrame()
        f.setFrameShape(QFrame.Shape.HLine)
        return f

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    def _choose_dir(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Select Output Directory", self._output_dir)
        if d:
            self._output_dir = d
            self.dir_label.setText(d)

    def _toggle(self) -> None:
        if self._worker is None:
            self._start_recording()
        else:
            self._stop_recording()

    def _start_recording(self) -> None:
        filename    = self._clean_filename()
        output_path = Path(self._output_dir) / filename

        if output_path.exists():
            box = QMessageBox(self)
            box.setStyleSheet(DARK_STYLE)
            box.setWindowTitle("Overwrite?")
            box.setIcon(QMessageBox.Icon.Question)
            box.setText(f"'{filename}' already exists.\nOverwrite?")
            box.setStandardButtons(
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            box.setDefaultButton(QMessageBox.StandardButton.No)
            if box.exec() != QMessageBox.StandardButton.Yes:
                return

        cmd = self._build_cmd(output_path)

        self._worker = RecordingWorker(cmd)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

        self._elapsed = 0
        self._tick_timer.start(1000)

        self.record_btn.setObjectName("stop_btn")
        self.record_btn.setText("  STOP")
        self.record_btn.setStyleSheet(DARK_STYLE)

        self.status_label.setText(f"Recording -> {filename}")
        self.monitor_combo.setEnabled(False)
        self.mic_combo.setEnabled(False)
        self.sys_combo.setEnabled(False)
        self.fps_combo.setEnabled(False)

    def _stop_recording(self) -> None:
        if self._worker:
            self._worker.stop()
            self._worker = None

        self._tick_timer.stop()

        self.record_btn.setObjectName("record_btn")
        self.record_btn.setText("  RECORD")
        self.record_btn.setStyleSheet(DARK_STYLE)

        self.timer_label.setText("00:00:00")
        self.status_label.setText("Ready")
        self._elapsed = 0
        self.monitor_combo.setEnabled(True)
        self.mic_combo.setEnabled(True)
        self.sys_combo.setEnabled(True)
        self.fps_combo.setEnabled(True)

    def _tick(self) -> None:
        self._elapsed += 1
        h =  self._elapsed // 3600
        m = (self._elapsed % 3600) // 60
        s =  self._elapsed % 60
        self.timer_label.setText(f"{h:02d}:{m:02d}:{s:02d}")

    def _on_finished(self) -> None:
        if self._worker is not None:
            self._stop_recording()

    def _on_error(self, msg: str) -> None:
        self._stop_recording()
        box = QMessageBox(self)
        box.setStyleSheet(DARK_STYLE)
        box.setWindowTitle("Recording Failed")
        box.setIcon(QMessageBox.Icon.Critical)
        box.setText("ffmpeg exited early. Details:")
        box.setDetailedText(msg)
        box.exec()

    def _show_log(self) -> None:
        log_path = os.path.join(tempfile.gettempdir(), "screen_of_death_ffmpeg.log")
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
        except FileNotFoundError:
            content = "(no log yet)"
        box = QMessageBox(self)
        box.setStyleSheet(DARK_STYLE)
        box.setWindowTitle("ffmpeg log")
        box.setText("Last ffmpeg session:")
        box.setDetailedText(content or "(empty)")
        box.exec()

    def closeEvent(self, event) -> None:
        keyboard.unhook_all()
        if self._worker:
            self._stop_recording()
        event.accept()

    # ------------------------------------------------------------------
    # ffmpeg command builder
    # ------------------------------------------------------------------

    def _clean_filename(self) -> str:
        name = self.filename_edit.text().strip() or "recording"
        if not name.lower().endswith(".mp4"):
            name += ".mp4"
        return name

    def _build_cmd(self, output_path: Path) -> list[str]:
        mon_idx               = self.monitor_combo.currentIndex()
        _, mon                = self._monitors[mon_idx]
        mic                   = self.mic_combo.currentText()
        has_mic               = mic != "No Mic"
        sys_idx               = self.sys_combo.currentIndex()
        _, sys_type, sys_name = self._sys_devices[sys_idx]
        has_sys               = bool(sys_type)
        fps                   = 60 if self.fps_combo.currentIndex() == 1 else 30
        use_ddagrab           = mon_idx > 0

        cmd = ["ffmpeg", "-y"]

        # ---- Audio inputs ----
        # -thread_queue_size 512: prevents queue stalls when the capture thread
        # runs slightly behind — a common cause of audio/video desync.
        mic_idx = sys_audio_idx = -1
        next_idx = 0

        if has_mic:
            cmd += [
                "-thread_queue_size", "512",
                "-f", "dshow", "-rtbufsize", "256M",
                "-i", f"audio={mic}",
            ]
            mic_idx   = next_idx
            next_idx += 1

        if has_sys:
            if sys_type == "wasapi":
                cmd += [
                    "-thread_queue_size", "512",
                    "-f", "wasapi", "-loopback", "1",
                    "-i", sys_name,
                ]
            else:
                cmd += [
                    "-thread_queue_size", "512",
                    "-f", "dshow", "-rtbufsize", "256M",
                    "-i", f"audio={sys_name}",
                ]
            sys_audio_idx = next_idx
            next_idx     += 1

        # ---- Build filter_complex ----
        # Audio always goes through filter_complex so aresample=async=1000 is
        # applied consistently. async=1000 dynamically resamples audio to chase
        # the video timestamps, correcting both initial offset and clock drift.
        fc_parts: list[str] = []

        if use_ddagrab:
            display_idx = mon_idx - 1
            fc_parts.append(
                f"ddagrab=output_idx={display_idx}:framerate={fps},"
                f"hwdownload,format=bgra[v]"
            )

        if has_mic and has_sys:
            fc_parts.append(
                f"[{mic_idx}:a][{sys_audio_idx}:a]"
                f"amix=inputs=2:duration=first,"
                f"aresample=async=1000[aout]"
            )
        elif has_mic or has_sys:
            a_idx = mic_idx if has_mic else sys_audio_idx
            fc_parts.append(f"[{a_idx}:a]aresample=async=1000[aout]")

        if fc_parts:
            cmd += ["-filter_complex", ";".join(fc_parts)]

        # ---- Stream mapping ----
        if use_ddagrab:
            cmd += ["-map", "[v]"]
        else:
            cmd += [
                "-thread_queue_size", "512",
                "-f", "gdigrab", "-framerate", str(fps), "-i", "desktop",
            ]
            cmd += ["-map", f"{next_idx}:v:0"]

        if has_mic or has_sys:
            cmd += ["-map", "[aout]"]

        # ---- Video encoding ----
        cmd += encoder_video_args(self._encoder)
        cmd += ["-r", str(fps)]

        # ---- Audio encoding ----
        if has_mic or has_sys:
            cmd += ["-c:a", "aac", "-b:a", "192k"]

        # -max_muxing_queue_size: prevents the muxer dropping packets when
        # audio and video arrive at different rates (common with dshow + ddagrab).
        cmd += ["-max_muxing_queue_size", "9999"]

        cmd.append(str(output_path))
        return cmd

# =============================================================================
# Entry Point
# =============================================================================

def main() -> None:
    app = QApplication(sys.argv)
    app.setStyleSheet(DARK_STYLE)

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Initializing...", "Enumerating devices...", "Ready."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = ScreenOfDeath()
    win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
